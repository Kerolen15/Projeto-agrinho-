let player;
let items = [];
let score = 0;
let bgColor;

function setup() {
  createCanvas(800, 600);
  player = new Player();
  bgColor = color(180, 220, 255); // Céu azul claro
}

function draw() {
  background(bgColor);
  drawGround();
  drawCity();

  // Itens caindo
  for (let i = items.length - 1; i >= 0; i--) {
    items[i].update();
    items[i].show();

    if (items[i].hits(player)) {
      score++;
      items.splice(i, 1);
    } else if (items[i].offScreen()) {
      items.splice(i, 1);
    }
  }

  // Adiciona novos itens
  if (random(1) < 0.02) {
    items.push(new Item());
  }

  // Jogador
  player.update();
  player.show();

  // Pontuação
  fill(0);
  textSize(24);
  text("Pontuação: " + score, 10, 30);

  // Título
  textAlign(CENTER);
  textSize(28);
  text("Festejando Campo Cidade", width / 2, 60);
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    player.setDir(-1);
  } else if (keyCode === RIGHT_ARROW) {
    player.setDir(1);
  }
}

function keyReleased() {
  player.setDir(0);
}

class Player {
  constructor() {
    this.x = width / 2;
    this.dir = 0;
  }

  update() {
    this.x += this.dir * 5;
    this.x = constrain(this.x, 0, width - 50);
  }

  show() {
    fill(100, 100, 200);
    rect(this.x, height - 40, 50, 30);
  }

  setDir(dir) {
    this.dir = dir;
  }
}

class Item {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.size = 25;
    this.color = color(100, 200, 100);
  }

  update() {
    this.y += 3;
  }

  show() {
    fill(this.color);
    ellipse(this.x, this.y, this.size);
  }

  hits(player) {
    return this.y + this.size / 2 > height - 40 &&
           this.x > player.x &&
           this.x < player.x + 50;
  }

  offScreen() {
    return this.y > height;
  }
}

function drawGround() {
  fill(100, 200, 100);
  rect(0, height - 10, width, 10);
}

function drawCity() {
  fill(180);
  for (let i = 0; i < width; i += 80) {
    rect(i, height - 120, 50, 100);
  }
}